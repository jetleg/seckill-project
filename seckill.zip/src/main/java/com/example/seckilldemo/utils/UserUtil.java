package com.example.seckilldemo.utils;

import com.example.seckilldemo.entity.TUser;

import java.util.ArrayList;
import java.util.List;

/**
 * 生成用户工具类
 *
 * @author: LC
 * @date 2022/3/4 3:29 下午
 * @ClassName: UserUtil
 */
public class UserUtil {


}
